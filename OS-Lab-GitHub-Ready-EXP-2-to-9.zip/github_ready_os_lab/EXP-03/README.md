# Experiment 3 — System Calls: Fork, Exit, Getpid, Wait, Close

> GitHub-ready version prepared from the uploaded lab document.

## EXP NO : 3 System Calls: Fork, Exit, Getpid, Wait, Close

## C PROGRAM : fork()

```c
#include <stdio.h>
```

```c
#include <stdlib.h>
```

```c
#include <unistd.h>
```

```c
#include <sys/wait.h>
int main()
{
    pid_t pid;
    pid = fork();
    if(pid < 0)
    {
        printf("Fork Failed\n");
        exit(1);
    }
    else if(pid == 0)
    {
        printf("\nCHILD PROCESS");
        printf("\nChild PID : %d", getpid());
        printf("\nParent PID : %d\n", getppid());
        exit(0);
    }
    else
    {
        wait(NULL);
        printf("\nPARENT PROCESS");
        printf("\nParent PID : %d", getpid());
        printf("\nParent's Parent PID : %d\n", getppid());
    }
    return 0;
}
```

## SHELL SCRIPT :

```bash
#!/bin/bash
echo "Parent Process ID : $$"
(
echo "Child Process ID : $$"
echo "Parent Process ID : $PPID"
exit 0
) &
wait
echo "Child Process Completed"
```

## C PROGRAM : wait()

```c
#include <stdio.h>
```

```c
#include <unistd.h>
```

```c
#include <sys/wait.h>
int main()
{
    pid_t pid;
    pid = fork();
    if(pid == 0)
    {
        printf("Child Process Running\n");
        sleep(5);
        printf("Child Process Completed\n");
    }
    else
    {
        wait(NULL);
        printf("Parent Resumes Execution\n");
    }
    return 0;
}
```

## SHELL SCRIPT :

```bash
#!/bin/bash
  (echo "Child Process Running"
 sleep 5
echo "Child Process Completed"
) &
 Wait
 echo "Parent Resumes Execution"
```

## C PROGRAM : CLOSE

```c
#include <stdio.h>
```

```c
#include <fcntl.h>
```

```c
#include <unistd.h>
int main()
{
    int fd;
    fd = open("sample.txt", O_RDONLY);
    if(fd < 0)
    {
        printf("File Opening Failed\n");
        return 1;
    }
    printf("File Opened Successfully\n");
    close(fd);
    printf("File Closed Successfully\n");
    return 0;
}
```

## SHELL SCRIPTING :

```bash
#!/bin/bash
exec 3< sample.txt
 echo "File Opened Successfully"
exec 3<&-
echo "File Closed Successfull
```

## Output Screenshots

### output-01.png

![output-01.png](Outputs/output-01.png)

### output-02.png

![output-02.png](Outputs/output-02.png)

### output-03.png

![output-03.png](Outputs/output-03.png)

### output-04.png

![output-04.png](Outputs/output-04.png)

### output-05.png

![output-05.png](Outputs/output-05.png)

### output-06.png

![output-06.png](Outputs/output-06.png)
