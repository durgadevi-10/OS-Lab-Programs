# Experiment 6 — Semaphore Implementation

> GitHub-ready version prepared from the uploaded lab document.

## EXP NO : 6 Semaphore Implementation

## C PROGRAM :

```c
#include <stdlib.h>
```

```c
#include <unistd.h>
```

```c
#include <semaphore.h>
```

```c
#include <sys/mman.h>
```

```c
#include <sys/wait.h>
int main()
{
    sem_t *sem;
    sem = mmap(NULL, sizeof(sem_t),
               PROT_READ | PROT_WRITE,
               MAP_SHARED | MAP_ANONYMOUS,
               -1, 0);
    sem_init(sem, 1, 1);
    if(fork() == 0)
    {
        sem_wait(sem);
        printf("Child Process Entering Critical Section\n");
        sleep(3);
        printf("Child Process Leaving Critical Section\n");
        sem_post(sem);
        exit(0);
    }
    sem_wait(sem);
    printf("Parent Process Entering Critical Section\n");
    sleep(3);
    printf("Parent Process Leaving Critical Section\n");
    sem_post(sem);
    wait(NULL);
    sem_destroy(sem);
    return 0;
}
```

## SHELL SCRIPTING :

```bash
#!/bin/bash
LOCKFILE="/tmp/mylock"
while [ -f "$LOCKFILE" ]
do
    sleep 1
done
touch "$LOCKFILE"
echo "Entering Critical Section"
sleep 5
echo "Leaving Critical Section"
rm -f "$LOCKFILE"
```

## Output Screenshots

### output-01.png

![output-01.png](Outputs/output-01.png)

### output-02.png

![output-02.png](Outputs/output-02.png)
