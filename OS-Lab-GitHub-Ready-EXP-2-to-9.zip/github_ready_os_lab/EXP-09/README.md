# Experiment 9 — Threading

> GitHub-ready version prepared from the uploaded lab document.

## EXP NO : 9 Threading

    C PROGRAM :

```c
#include <stdio.h>
```

```c
#include <stdlib.h>
```

```c
#include <pthread.h>
```

```c
#include <unistd.h>
void *thread_function(void *arg)
{   int i;
    for(i = 1; i <= 5; i++)
    {
        printf("Thread Executing : %d\n", i);
        sleep(1);
    }
    pthread_exit(NULL);
}
int main()
{
    pthread_t t1, t2;
    pthread_create(&t1, NULL, thread_function, NULL);
    pthread_create(&t2, NULL, thread_function, NULL);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("All Threads Completed\n");
    return 0;
}
```

## SHELL SCRIPTING :

```bash
#!/bin/bash
task1()
{
    for i in 1 2 3 4 5
    do
        echo "Thread 1 : $i"
        sleep 1
    done
}
task2()
{
    for i in 1 2 3 4 5
    do
        echo "Thread 2 : $i"    sleep 1
    done
}
task1 &
task2 &
wait
echo "All Threads Completed"
```

## Output Screenshots

### output-01.png

![output-01.png](Outputs/output-01.png)

### output-02.png

![output-02.png](Outputs/output-02.png)
