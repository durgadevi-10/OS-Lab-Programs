# OS Lab Programs

C and Shell Programming Lab Programs with Outputs

## Experiments

- [Experiment 2](EXP-02/README.md)
- [Experiment 3](EXP-03/README.md)
- [Experiment 4](EXP-04/README.md)
- [Experiment 5](EXP-05/README.md)
- [Experiment 6](EXP-06/README.md)
- [Experiment 7](EXP-07/README.md)
- [Experiment 8](EXP-08/README.md)
- [Experiment 9](EXP-09/README.md)

Each experiment folder contains a GitHub-readable README with the code/script and output screenshots.
The original uploaded document/PDF is also retained as a reference.