# Experiment 5 — Inter Process Communication (IPC)

> GitHub-ready version prepared from the uploaded lab document.

## EXP NO : 5 Inter Process Communication (IPC)

## C PROGRAM :

```c
#include<stdio.h>
```

```c
#include<stdlib.h>
```

```c
#include<unistd.h>
```

```c
#include<string.h>
```

```c
#include<sys/wait.h>
int main()
{
    int fd[2];
    pid_t pid;
    char message[] = "Hello from Child Process";
    char buffer[100];
    pipe(fd);
    pid = fork();
    if(pid == 0)
    {
        close(fd[0]);
        write(fd[1], message, strlen(message)+1);
        close(fd[1]);
        exit(0);
    }
    else
    {
        wait(NULL);
        close(fd[1]);
        read(fd[0], buffer, sizeof(buffer));
        printf("Message received from child: %s\n", buffer);
        close(fd[0]);
    }
    return 0;
}
```

## SHELL SCRIPTING :

```bash
#!/bin/bash
 echo "Hello from Child Process" | cat
Alternative Shell Script
```

```bash
#!/bin/bash
 ( echo "Message from Child Process"
) | while read msg
do
echo "Parent Received: $msg"
 done
```

## Output Screenshots

### output-01.png

![output-01.png](Outputs/output-01.png)

### output-02.png

![output-02.png](Outputs/output-02.png)

### output-03.png

![output-03.png](Outputs/output-03.png)
